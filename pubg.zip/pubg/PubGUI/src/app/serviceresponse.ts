export class ServiceResponse{
    message:string;
}