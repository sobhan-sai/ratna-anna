import { Attribute } from "./attribute";

export class Tournament{
    id: string;
    attributes: Attribute;
}