export class Attribute{
    createdAt: any;
}