export class Match{
    id: string;
    titleId: string;
    createdAt: string;
    duration: string;
    mapName: string;
    gameMode: string;
    userId: string;
}