import { MatchAttributes } from './matchattributes';

export class MatchDetails{
    id:string;
    attributes:MatchAttributes;
    comments:string;
}