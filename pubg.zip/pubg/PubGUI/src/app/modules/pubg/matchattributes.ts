export class MatchAttributes{
    createdAt: any;
    duration: number;
    gameMode: string;
    mapName: string;
    titleId: string;
    seasonState: string;
}