import { TestBed } from '@angular/core/testing';

import { PubginterceptorService } from './pubginterceptor.service';

describe('PubginterceptorService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PubginterceptorService = TestBed.get(PubginterceptorService);
    expect(service).toBeTruthy();
  });
});
