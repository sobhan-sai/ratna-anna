package com.stackroute.favouriteservice.constants;

public class FavouriteServiceConstants {

	public final static String DELETE_MESSAGE = "Deleted Successfully!!";
	public final static String UPDATE_MESSAGE = "Updated Successfully!!";
	public final static String SAVE_MESSAGE = "Match Successfully added!!";
	
}
