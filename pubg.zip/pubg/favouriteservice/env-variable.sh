export MONGO_DATABASENAME=pubg
export MONGO_URL=mongodb://localhost:27017/pubg
