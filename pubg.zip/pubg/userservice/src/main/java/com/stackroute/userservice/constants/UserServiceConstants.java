package com.stackroute.userservice.constants;

public class UserServiceConstants {
	
	public static final String REGISTER_SUCCESS = "Successfully Registered!";
	public static final String SERVICE_FAILURE = "Try After sometime";

}
