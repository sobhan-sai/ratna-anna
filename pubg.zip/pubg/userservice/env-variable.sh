export MYSQL_DATABASE=UserDb
export MYSQL_URL=jdbc:mysql://localhost:3306/UserDb
export MYSQL_USER=root
export MYSQL_PASSWORD=root

